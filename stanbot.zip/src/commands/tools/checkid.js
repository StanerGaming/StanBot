const { SlashCommandBuilder } = require('discord.js');
const Axios = require(`axios`);

module.exports = {
    data: new SlashCommandBuilder()
        .setName('checkid')
        .setDescription('Returns ping or something I dunno')
        .addStringOption(option => 
            option
            .setName('target')
            .setDescription('who to search for')
            .setRequired(true)),
        async execute(interaction, client){
            const message = await interaction.deferReply({
                fetchReply: true
            });
            const usertoSearchFor = interaction.options.getString('target')
        

        const newMessage = `Searching for ${usertoSearchFor}`
        await interaction.editReply({
            content:newMessage
        });
        Axios.post("https://apis.roblox.com/messaging-service/v1/universes/4835314565/topics/CheckIfPlayerInGame", {'message': `${usertoSearchFor}` }, {
            headers:{
            'x-api-key': 'Dg1OUDaa3EaYMPM+VCJZHX9tcN7fHYdugrkNdl1NyKlcLuDo',
            'Content-Type': 'application/json' 
            }
        }
        ).then(response => (
            console.log(response.data)
        ))
    }
}
